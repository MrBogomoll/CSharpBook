using ExpenseTracker.Models;
using ExpenseTracker.Reports;

Expense[] expenses = new Expense[]
{
    new Expense("Еда", 120),
    new Expense("Транспорт", 80)
};
Console.WriteLine($"Итого: {ExpenseReport.Total(expenses)} руб.");
