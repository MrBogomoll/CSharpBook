using ExpenseTracker.Models;

namespace ExpenseTracker.Reports;

public static class ExpenseReport
{
    public static int Total(Expense[] expenses)
    {
        int total = 0;
        foreach (Expense expense in expenses)
            total += expense.Amount;
        return total;
    }
}
