namespace ExpenseTracker.Models;

public class Expense
{
    public string Category { get; }
    public int Amount { get; }

    public Expense(string category, int amount)
    {
        Category = category;
        Amount = amount;
    }

    public string Describe() => $"{Category}: {Amount} руб.";
}
