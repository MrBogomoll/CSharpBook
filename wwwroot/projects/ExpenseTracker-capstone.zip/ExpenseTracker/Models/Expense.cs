namespace ExpenseTracker.Models;

public sealed record Expense(int Amount, string Category);
