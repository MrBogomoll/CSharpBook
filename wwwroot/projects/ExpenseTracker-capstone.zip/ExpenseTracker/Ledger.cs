using System.Text.Json;
using ExpenseTracker.Models;

namespace ExpenseTracker;

public sealed class Ledger
{
    private List<Expense> _expenses = new();

    public long Total => _expenses.Sum(expense => (long)expense.Amount);

    public void Add(int amount, string category) => _expenses.Add(new Expense(amount, category));

    public long TotalFor(string category) =>
        _expenses.Where(expense => expense.Category.Equals(category, StringComparison.OrdinalIgnoreCase))
                 .Sum(expense => (long)expense.Amount);

    public void Save(string path) =>
        File.WriteAllText(path, JsonSerializer.Serialize(_expenses));

    public bool Load(string path)
    {
        if (!File.Exists(path)) return false;
        var loaded = JsonSerializer.Deserialize<List<Expense>>(File.ReadAllText(path));
        if (loaded is null || loaded.Any(item =>
            item is null || item.Amount <= 0 || string.IsNullOrWhiteSpace(item.Category)))
            return false;

        _expenses = loaded;
        return true;
    }
}
