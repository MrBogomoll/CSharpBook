using System.Text.Json;
using ExpenseTracker;

const string path = "expenses.json";
var ledger = new Ledger();
Console.WriteLine("Команды: добавить СУММА КАТЕГОРИЯ, итог, категория ИМЯ, сохранить, загрузить, выход");

while (Console.ReadLine() is string input)
{
    var parts = input.Trim().Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
    if (parts.Length == 0) continue;

    switch (parts[0])
    {
        case "добавить":
            var fields = parts.Length == 2
                ? parts[1].Split(' ', 2, StringSplitOptions.RemoveEmptyEntries)
                : Array.Empty<string>();
            if (fields.Length == 2 && int.TryParse(fields[0], out int amount) &&
                amount > 0 && !string.IsNullOrWhiteSpace(fields[1]))
            {
                ledger.Add(amount, fields[1].Trim());
                Console.WriteLine("Добавлено.");
            }
            else Console.WriteLine("Нужны положительная сумма и категория.");
            break;

        case "итог":
            Console.WriteLine($"Итого: {ledger.Total} руб.");
            break;

        case "категория" when parts.Length == 2:
            Console.WriteLine($"Категория: {ledger.TotalFor(parts[1].Trim())} руб.");
            break;

        case "сохранить":
            try
            {
                ledger.Save(path);
                Console.WriteLine("Сохранено.");
            }
            catch (Exception error) when (error is IOException or UnauthorizedAccessException)
            {
                Console.WriteLine("Файл недоступен.");
            }
            break;

        case "загрузить":
            try
            {
                Console.WriteLine(ledger.Load(path) ? "Загружено." : "Нет пригодных данных.");
            }
            catch (Exception error) when (error is IOException or UnauthorizedAccessException)
            {
                Console.WriteLine("Файл недоступен.");
            }
            catch (JsonException) { Console.WriteLine("Не удалось прочитать JSON."); }
            break;

        case "выход":
            return;

        default:
            Console.WriteLine("Неизвестная команда.");
            break;
    }
}
