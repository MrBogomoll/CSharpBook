using Microsoft.VisualStudio.TestTools.UnitTesting;

[assembly: Parallelize(Scope = ExecutionScope.MethodLevel)]

namespace ExpenseTracker.Tests;

[TestClass]
public sealed class LedgerTests
{
    [TestMethod]
    public void EmptyLedgerReturnsZero()
    {
        var ledger = new Ledger();

        Assert.AreEqual(0L, ledger.Total);
        Assert.AreEqual(0L, ledger.TotalFor("Спорт"));
    }

    [TestMethod]
    public void CategoryIgnoresCase()
    {
        var ledger = new Ledger();
        ledger.Add(120, "Еда");
        ledger.Add(80, "Транспорт");
        ledger.Add(30, "еда");

        Assert.AreEqual(230L, ledger.Total);
        Assert.AreEqual(150L, ledger.TotalFor("ЕДА"));
    }

    [TestMethod]
    public void TotalCanExceedIntRange()
    {
        var ledger = new Ledger();
        ledger.Add(int.MaxValue, "Еда");
        ledger.Add(10, "Еда");

        Assert.AreEqual(2147483657L, ledger.Total);
    }
}
