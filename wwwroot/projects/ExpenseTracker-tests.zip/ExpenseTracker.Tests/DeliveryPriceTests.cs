namespace ExpenseTracker.Tests;

[TestClass]
public sealed class DeliveryPriceTests
{
    [TestMethod]
    [DataRow(999, 100)]
    [DataRow(1000, 0)]
    [DataRow(1001, 0)]
    public void Calculate_UsesFreeDeliveryThreshold(int orderTotal, int expected)
    {
        int actual = DeliveryPrice.Calculate(orderTotal);
        Assert.AreEqual(expected, actual);
    }
}
