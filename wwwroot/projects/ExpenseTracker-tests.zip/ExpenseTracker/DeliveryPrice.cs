namespace ExpenseTracker;

public static class DeliveryPrice
{
    public static int Calculate(int orderTotal) => orderTotal >= 1000 ? 0 : 100;
}
